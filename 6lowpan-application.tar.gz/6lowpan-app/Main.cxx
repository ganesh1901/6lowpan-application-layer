#include <fltk/run.h>
#include <fltk/Window.h>
#include <fltk/Group.h>
#include <fltk/Button.h>
#include <fltk/Input.h>
#include <fltk/ask.h>
#include <fltk/TextDisplay.h>
#include <fltk/InputBrowser.h>
#include <string.h>
#include <stdio.h>

fltk::Window *w;
fltk::Group *Main_grp;

fltk::TextDisplay *txt;
fltk::InputBrowser *ib;

int MainMenu();

/*****************   6lowpan API's   ************************/

int Initialize(char *);
int SendCommand(char *, int);
int Response(char *, int, int);
int ChangeMachineID();
void Close();

/*****************   6lowpan API's   ************************/

char Selected[12], Command[40];

const char *TransPort[2] = {"/dev/ttyUSB0", "/dev/ttyO5"};

static void h2a(char* hex,char* asc,int Hlen) 
{
        int i; 
        for(i=0;i<Hlen;i++)
        {
                switch(hex[i]){
                        case 0x0A: asc[i]='A';break;
                        case 0x0B: asc[i]='B';break;
                        case 0x0C: asc[i]='C';break;
                        case 0x0D: asc[i]='D';break;
                        case 0x0E: asc[i]='E';break;
                        case 0x0F: asc[i]='F';break;
                        default: asc[i]=hex[i]+0x30;break;
                }
        }
}

static int Hex2Ascii(char *Hexbuf, char *Ascbuf, int HexLength) 
{
        int i,j=0;
        char temp[HexLength*2];
        memset(Ascbuf, 0x00, HexLength*2);
        for(i=0; i<HexLength;i++,j+=2) {
                temp[j]=(char)((Hexbuf[i] >> 4) & 0x0F);                        //Getting Each byte.
                temp[j+1] =(char)(Hexbuf[i] & 0x0F);
        }
        h2a(temp,Ascbuf,j);
        return j;
}

void cb_InputBrowser(fltk::InputBrowser *ib, void *) 
{
	memset(Selected, '\0', sizeof(Selected));
        fltk::InputBrowser *b1 = (fltk::InputBrowser*)ib;
        fltk::Widget *w = b1->item();
        sprintf(Selected,"%s",w && w->label() ? w->label() : "null");
#ifdef DEBUG
	fprintf(stderr, "Selected : %s\n", Selected);
#endif
        return;	
}

void cb_btnCommandEnt (fltk::Button *, void *) 
{
	int Ret = 0, AsciiLen = 0;
	char Resp[512], AsciiBuff[512];

	memset(Resp, 0x00, sizeof Resp);
        txt->text(" ");
        if(strlen(Selected) == 0) {
                txt->textcolor(fltk::RED);
                txt->text("Please select Communication Mode");
                fltk::flush();
                return;
        }
	else if (strlen(Command) == 0) {
                txt->textcolor(fltk::RED);
                txt->text("Please Enter Command Data");
                fltk::flush();
                return;
        }
	if(strcmp(Selected, "USB") == 0) {
#ifdef DEBUG
                fprintf(stderr, "Port : %s\n", TransPort[0]);
#endif
                Ret = Initialize((char *)TransPort[0]);
        }
        else if(strcmp(Selected, "RJ11") == 0) {
#ifdef DEBUG
                fprintf(stderr, "Port : %s\n", TransPort[1]);
#endif
                Ret = Initialize((char *)TransPort[1]);
        }
        if(Ret < 0){
                txt->textcolor(fltk::RED);
                txt->text("select Valid Communication Mode");
                fltk::flush();
                return;
        }
        txt->textcolor(fltk::BLACK);
        txt->text("Processing...! Please Wait....");
        fltk::flush();
        if(SendCommand(Command, strlen(Command) < 0)) {
                txt->text(" ");
                txt->textcolor(fltk::RED);
                txt->text("Unable to Send Command");
                fltk::flush();
                return;
        }
	Ret = Response(Resp, 256, 10);
	if(Ret < 0) {
		txt->text(" ");
                txt->textcolor(fltk::RED);
                txt->text("Unable to fetch Command Response");
                fltk::flush();
                return;
	}
	Close();
	Hex2Ascii(Resp, AsciiBuff, Ret);
	txt->text(" ");
	txt->text(AsciiBuff);
	fltk::flush();
}

void cb_inpCommand(fltk::Input *ip, void *) 
{
	txt->text(" ");
	fltk::flush();	
	if(strlen(Command) >= 12) {
		ip->value(Command);
		fltk::alert("Command Length Exceeded");
		return;
	} 	
	memset(Command, 0x00, sizeof Command);
	strcpy(Command, ip->value());
	return;
}

void cb_btnChangeMacId(fltk::Button *, void *) 
{
	int Ret = 0;
	txt->text(" ");
	if(strlen(Selected) == 0) {
		txt->textcolor(fltk::RED);
		txt->text("Please select Communication Mode");
		fltk::flush();
		return;
	}
	if(strcmp(Selected, "USB") == 0) {
#ifdef DEBUG
		fprintf(stderr, "Port : %s\n", TransPort[0]);
#endif
		Ret = Initialize((char *)TransPort[0]);
	}
	else if(strcmp(Selected, "RJ11") == 0) {
#ifdef DEBUG
		fprintf(stderr, "Port : %s\n", TransPort[1]);
#endif
		Ret = Initialize((char *)TransPort[1]);
	}
	if(Ret < 0){
		txt->textcolor(fltk::RED);
                txt->text("select Valid Communication Mode");
                fltk::flush();
                return;
	}
	txt->textcolor(fltk::BLACK);
	txt->text("Processing...! Please Wait....");
	fltk::flush();
	if(ChangeMachineID() < 0) {
		txt->text(" ");
		txt->textcolor(fltk::RED);
		txt->text("Unable to Change MACID");
		fltk::flush();
		return;
	}
	txt->text(" ");
	Close();
	txt->textcolor(fltk::BLUE);
	txt->text("MACID Changed Successfully");
	fltk::flush();
	return;
}

int MainMenu() 
{
	int y = 0;
	memset(Selected, 0x00, sizeof Selected);
	Main_grp = new fltk::Group(0, 0, 320, 240, "");
	Main_grp->set_vertical();
	Main_grp->begin();
	{
		ib = new fltk::InputBrowser(00, y, 320, 40, " ");
		ib->take_focus();
                ib->textfont(fltk::TIMES_BOLD);
                ib->textsize(16);
                ib->text(" ---SELECT---");
                ib->add("USB");
                ib->add("RJ11");
		ib->callback((fltk::Callback*)cb_InputBrowser);
	}
	y = y + 45;
	{
		fltk::Button *o = new fltk::Button(00, y, 320, 40, "Change MACID");
		o->box(fltk::FLAT_BOX);
		o->labelfont(fltk::TIMES_BOLD);
		o->labelsize(16);
		o->callback((fltk::Callback*)cb_btnChangeMacId);
	}	
	y = y + 45;
	{
		fltk::Input *o = new fltk::Input(00, y, 320, 40, "");
		o->box(fltk::FLAT_BOX);
		o->textfont(fltk::TIMES_BOLD);
		o->when(fltk::WHEN_CHANGED);
		o->textsize(16);
		o->callback((fltk::Callback*)cb_inpCommand);
	}
	{
		fltk::Button *o = new fltk::Button(325, y, 320, 40, "");
		o->shortcut('\r');
		o->callback((fltk::Callback*)cb_btnCommandEnt);
	}
	y = y + 45;
	{
		txt = new fltk::TextDisplay(00, y, 320, 85, "");
		txt->box(fltk::FLAT_BOX);
		txt->color((fltk::Color)246);
		txt->textfont(fltk::TIMES_BOLD);
		txt->deactivate();
		txt->textsize(16);
		txt->text("");
	}
}

int main(int argc, char **argv) 
{
	w = new fltk::Window(0, 0, 320, 240, " ");
	w->box(fltk::FLAT_BOX);
	w->color((fltk::Color)246);
	w->begin();
		MainMenu();
	w->end();
	w->show(argc, argv);
	return fltk::run();			
}
