#include <fltk/run.h>
#include <fltk/Window.h>
#include <fltk/Group.h>
#include <fltk/Button.h>
#include <fltk/Input.h>
#include <fltk/ask.h>
#include <fltk/Choice.h>
#include <fltk/TextDisplay.h>
#include <fltk/InputBrowser.h>
#include <poll.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define CONFIG "/home/debian/Config.txt"

fltk::Window *w;
fltk::Group *Main_grp;
fltk::Button *ProceedButton;
fltk::Choice *chCmd;
fltk::TextDisplay *txt;
fltk::InputBrowser *ib;

int MainMenu();

/*****************   6lowpan API's   ************************/

static int Initialize(char *, char *);
static int SendCommand(char *, int);
static int Response(char *, int, int);
static int ChangeMachineID();
static void Close();

/*****************   6lowpan API's   ************************/

char MeterInode[80], Selected[12], Command[40][40], SelectedBaudRate[40], Data[40][40][40],MeterMake[40];

int splitMeter = 0,NumNodes=0,count1=0;

const char *TransPort[2] = {"/dev/ttyUSB0", "/dev/ttyO5"};

static int fd = -1;

struct pollfd pollmsp;

struct speed_map {
    unsigned short speed;
    unsigned short value;
};

static const struct speed_map speeds[] = {
    {B0, 0},
    {B50, 50},
    {B75, 75},
    {B110, 110},
    {B134, 134},
    {B150, 150},
    {B200, 200},
    {B300, 300},
    {B600, 600},
    {B1200, 1200},
    {B1800, 1800},
    {B2400, 2400},
    {B4800, 4800},
    {B9600, 9600},
#ifdef    B19200
    {B19200, 19200},
#elif defined(EXTA)
    {EXTA, 19200},
#endif
#ifdef    B38400
    {B38400, 38400/256 + 0x8000U},
#elif defined(EXTB)
    {EXTB, 38400/256 + 0x8000U},
#endif
#ifdef B57600
    {B57600, 57600/256 + 0x8000U},
#endif
#ifdef B115200
    {B115200, 115200/256 + 0x8000U},
#endif
#ifdef B230400
    {B230400, 230400/256 + 0x8000U},
#endif
#ifdef B460800
    {B460800, 460800/256 + 0x8000U},
#endif
#ifdef B921600
    {B921600, 921600/256 + 0x8000U},
#endif
};

#define NUM_SPEEDS         (sizeof(speeds)/sizeof(speeds[0]))

static unsigned int tty_baud_to_value(speed_t speed) {

    int i = 0;
    do {

        if (speed == speeds[i].speed) {

            if (speeds[i].value & 0x8000U) {

                return ((unsigned long) (speeds[i].value) & 0x7fffU) * 256;
            }
            return speeds[i].value;
        }
    } while (++i < NUM_SPEEDS);

    return 0;
}

static speed_t tty_value_to_baud(unsigned int value) {

    int i = 0;
    do {

        if (value == tty_baud_to_value(speeds[i].speed)) {   //Trying to obtain the Valid BaudRate for the value passed

            return speeds[i].speed;        //returning the Valid BaudRate 
        }
    } while (++i < NUM_SPEEDS);  //checking for Baudrate

    return (speed_t) ~0;
}

static int htoi(const char c) {
	switch(c) {
		case 'a':
		case 'A': return 10;
		case 'b':
		case 'B': return 11;
		case 'c':
		case 'C': return 12;
		case 'd':
		case 'D': return 13;
		case 'e':
		case 'E': return 14;
		case 'f':
		case 'F': return 15;
		default: return (int)c - 0x30;
	}
}

static int atoh(const char *a) {
	return (16*htoi(a[0]) + htoi(a[1]));
}

static int Ascii2hex(char *Ascbuf,char *Hexbuf,int Asclen) {
	int ii,Hexcnt = 0,Ascnt = 0;
	if(Asclen % 2)							//Checking the input count.
		return 1;

	for(Ascnt=0;Ascnt < Asclen;Ascnt+=2,Hexcnt++)
		Hexbuf[Hexcnt] = atoh((Ascbuf+Ascnt));     		//converting each hex byte into Ascii.

	return Hexcnt;
}

static int Initialize(char *serialPort, char *BaudRate) 
{
  	struct termios options;
	speed_t value;
	/*char BaudRate[40];
	memset(BaudRate, 0x00, sizeof BaudRate);
	FILE *fp = fopen(ConfigFile, "r");
        if(fp == NULL) 
                return -3;
	
        fgets(BaudRate, 256, fp);
        fclose(fp);*/
	if((fd = open (serialPort, O_RDWR | O_NOCTTY )) < 0)
		return -1;

  	else
  	{
    		tcgetattr(fd, &options);
		value = tty_value_to_baud(atoi(BaudRate));
		if (value != (speed_t)~0) {
			cfsetispeed(&options, value);
			cfsetospeed(&options, value);
		}
		else
			return -2;
    		options.c_cflag &= ~PARENB;
    		options.c_cflag &= ~CSTOPB;
    		options.c_cflag &= ~CSIZE;
    		options.c_cflag |=  CS8;
    		options.c_iflag &= ~ICRNL;
    		options.c_cflag &= ~CRTSCTS;
    		options.c_lflag &= ~(ICANON | ECHO | ECHOE| ISIG);

		options.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP
                           | INLCR | IGNCR | ICRNL | IXON);
	        options.c_oflag &= ~OPOST;
        	options.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);

    		options.c_cc[VMIN] = 1;
    		options.c_cc[VTIME] = 200;

		pollmsp.fd = fd;
                pollmsp.events = POLLIN;

    		tcsetattr(fd,TCSANOW,&options);
		tcflush(fd, TCIOFLUSH);
		return fd;
  	}
}

static int Request(char *cmd, int Len) 
{   
#ifdef DEBUG
	int i;
	fprintf(stderr, "Port Req : ");
	for(i = 0; i < Len; i++)
		fprintf(stderr, "%02X ", (cmd[i]&0x000000FF));

	fprintf(stderr, "\n");
#endif
	if(write(fd, cmd, Len) == -1)					//pushing data over serial port.
		return 1;

	return 0;
}

static int Response(char *PortRes, int Len, int TimeOut) 
{ 
 	int noof_bytes = 0, cont = 0, Total = 0;
	char ascii[100];
	memset(ascii, 0x00, sizeof ascii);
	tcflush(fd, TCIOFLUSH);
        while(1)
        {
                if(cont == 0) { 
                        poll(&pollmsp, 1, (TimeOut*1000));
		}
                else 
                        poll(&pollmsp, 1, (TimeOut*100));
                
                if((pollmsp.revents & POLLIN) == 1) {

                        usleep(150000);
                        noof_bytes=read(fd, PortRes+Total, Len);
                        Total+=noof_bytes;
			fprintf(stdout,"\nAt receiving mode----\n");

#if 1
			for(int i=0;i<noof_bytes;i++)
				fprintf(stdout,"%02X ",PortRes[i]);
#endif
			cont++;
                }
                else{
                        if(cont == 0) {
#ifdef DEBUG
				fprintf(stderr, "No Data Found\n");
#endif
                                return -1;
			}
                        break;
                }
        }
	fprintf(stdout,"\n");
        return Total;
}

void Close() 
{
	close(fd);
}

static int SplitConfig()
{
	FILE *fp;
	char ftemp[128];
	splitMeter = 0;
	fprintf(stdout,"In split config function:\n");
	fp=fopen(CONFIG,"r");
	if(fp == NULL) {
		return -4;
	}
	
	NumNodes=0;
	while(fgets(ftemp,100,fp) != NULL)
	{
		int i=0; int count=0;
		NumNodes++;
		fprintf(stdout,"string from file:---%s\n",ftemp);

		while(ftemp[i] != '\0')
		{
			if(ftemp[i] == '|')
				count++;
			else if(ftemp[i] == '\n')
				ftemp[i] = '\0';
			i++;
		}
#ifdef DEBUG
		fprintf(stdout,"Pipe Count--%d \n",count);
#endif
		char *data = strtok(ftemp, "|");
		if(data == NULL)
			return -1;
		strcpy(Data[splitMeter][0], data);
#ifdef DEBUG
		fprintf(stdout,"No.of commands : %s\t",Data[splitMeter][0]);
#endif

		for(i=0;i<count;i++)
		{
			data = strtok(NULL,"|");
			if(data == NULL)
				return -2;
			strcpy(Data[splitMeter][i+1], data);
#ifdef DEBUG
			fprintf(stdout,"[%d]%[%d]--->%s\n",i,strlen(data),data);
#endif
		}
		splitMeter++;
		memset(ftemp,0x00,sizeof ftemp);
	}
	return 0;
}

static void h2a(char* hex,char* asc,int Hlen) 
{
        int i; 
        for(i=0;i<Hlen;i++)
        {
                switch(hex[i]){
                        case 0x0A: asc[i]='A';break;
                        case 0x0B: asc[i]='B';break;
                        case 0x0C: asc[i]='C';break;
                        case 0x0D: asc[i]='D';break;
                        case 0x0E: asc[i]='E';break;
                        case 0x0F: asc[i]='F';break;
                        default: asc[i]=hex[i]+0x30;break;
                }
        }
}

static int Hex2Ascii(char *Hexbuf, char *Ascbuf, int HexLength) 
{
        int i,j=0;
        char temp[HexLength*2];
        memset(Ascbuf, 0x00, HexLength*2);
        for(i=0; i<HexLength;i++,j+=2) {
                temp[j]=(char)((Hexbuf[i] >> 4) & 0x0F);                        //Getting Each byte.
                temp[j+1] =(char)(Hexbuf[i] & 0x0F);
        }
        h2a(temp,Ascbuf,j);
        return j;
}

int SendCommand(char *Data, int Length) 
{
	char HexData[40];
	int HexLen = -1;
	memset(HexData, 0x00, sizeof HexData);
	if(strlen(Data)!= Length)
		return -1;

	HexLen = Ascii2hex(Data, HexData, Length);
	if(HexLen == -1)
		return -2;

	if(Request(HexData, HexLen) < 0)
		return -3;

	return 0;
}

void cb_InputBrowser(fltk::InputBrowser *ib, void *) 
{
	memset(Selected, '\0', sizeof(Selected));
        fltk::InputBrowser *b1 = (fltk::InputBrowser*)ib;
        fltk::Widget *w = b1->item();
        sprintf(Selected,"%s",w && w->label() ? w->label() : "null");
#ifdef DEBUG
	fprintf(stderr, "Selected : %s\n", Selected);
#endif
        return;	
}

void cb_btnProceed(fltk::Button *, void *) 
{
	int Ret = 0, AsciiLen = 0,m = 0,j = 0;
	char Resp[512], HexBuff[512],Comm[512],temp[128],key_buf[128];
	long templong=0,templong1 = 0;   
	
	ProceedButton->deactivate();

	memset(Resp, 0x00, sizeof Resp);
        txt->text(" ");
        if(strlen(Selected) == 0) {
                txt->textcolor(fltk::RED);
                txt->text("Please select Communication Mode");
		ProceedButton->activate();
                fltk::flush();
                return;
        }
	else if (strlen(MeterInode) == 0) {
		txt->textcolor(fltk::RED);
		txt->text("Please Select Meter...");
		ProceedButton->activate();
		fltk::flush();
		return;
	}

	if(strcmp(Selected, "USB") == 0) {
#ifdef DEBUG
                fprintf(stderr, "Port : %s\tBaudRate : %s\n", TransPort[0], SelectedBaudRate);
#endif
                Ret = Initialize((char *)TransPort[0], SelectedBaudRate);
        }
        else if(strcmp(Selected, "LPR") == 0) {
#ifdef DEBUG
                fprintf(stderr, "Port : %s\tBaudRate : %s\n", TransPort[1], SelectedBaudRate);
#endif
                Ret = Initialize((char *)TransPort[1], SelectedBaudRate);
        }
        if(Ret < 0) {
                txt->textcolor(fltk::RED);
                txt->text("select Valid Communication Mode");
		ProceedButton->activate();
                fltk::flush();
                return;
        }
        txt->textcolor(fltk::BLACK);
        txt->text("Processing...! Please Wait....");
        fltk::flush();
	
	/***One time for mac id setting
 	*/

	Ret = SendCommand(MeterInode, strlen(MeterInode));
	if(Ret < 0) {
		txt->text(" ");
		txt->textcolor(fltk::RED);
		txt->text("Unable to Send Command");
		ProceedButton->activate();
		fltk::flush();
		return;
	}
	Ret = Response(Resp, 256, 10);
	if(Ret >0)
	{
		if(strstr(Resp,"OK")!=0)
		{
			txt->text()
			return 0;
		}
	}
	if(Ret < 0) {
		txt->text(" ");
		txt->textcolor(fltk::RED);
		txt->text("Unable to fetch Response");
		ProceedButton->activate();
		fltk::flush();
		return;
	}
	txt->text(" ");
	sprintf(temp,"MAC ID Changed Successfully...\n%d Received",Ret);
	txt->text(temp);
	fltk::flush();
	
	fprintf(stdout,"metermake--->%s\n",MeterMake);

	if(strcmp(MeterMake,"genus") == 0 )
	{	
		while(j<count1)
		{
			memset(Resp,0x00,sizeof Resp);
			memset(Comm,0x00,sizeof Comm);

			Ret = SendCommand(Command[j], strlen(Command[j])); 
			if(Ret < 0) {
				txt->text(" ");
				txt->textcolor(fltk::RED);
				txt->text("Unable to Send Command");
				ProceedButton->activate();
				fltk::flush();
				return;
			}
			Ret = Response(Resp, 256, 10);
			if(Ret < 0) {
				txt->text(" ");
				txt->textcolor(fltk::RED);
				txt->text("Unable to fetch Response");
				ProceedButton->activate();
				fltk::flush();
				return;
			}
			txt->text(" ");
			txt->text("Data Received ...\n");
			sprintf(temp,"for Command [%d]\n Successfully",j);
			txt->append(temp);
			if(j == 0)
			{
				if((Ret=28)||(Ret==29))
				{
					if((Resp[10]==0x06 && Resp[11]==0x02)||(Resp[11]==0x06 && Resp[12]==0x02))
					{


						for(m=(Ret-14); m>11;m--) //Reliance
						{
							key_buf[m] = Resp[m];
							printf("%d---%02x ",m,key_buf[m]);
						}
						templong=(long int)key_buf[14]*65536+(long int)key_buf[13]*256+(long int)key_buf[12];
						printf("GENUS Meter-Num [%8ld]\n",templong);
						sprintf(temp,"GENUS Meter-Num [%8ld]\n",templong);
						txt->text(temp);
					}
					else
					{
						templong=0;
						printf("Error In Reading GENUS Meter-Num [%8ld]\n",templong);
						sprintf(temp,"Error In Reading GENUS Meter-Num [%8ld]\n",templong);
						txt->text(temp);
					}
				}
				else
				{
					txt->text("Invalid Response... \n In the METER COMMAND...");
					return;
				}

			}	
			if(j == 1)
			{
				if((Ret==28)||(Ret==29))
				{
					if((Resp[10]==0x06 && Resp[11]==0x02)||(Resp[11]==0x06 && Resp[12]==0x02))
					{

						for(m=(Ret-15); m>11;m--) 
						{
							key_buf[m] = Resp[m];
							printf("%d---%02x ",m,key_buf[m]);
						}
						templong1=(long int)key_buf[13]*256+(long int)key_buf[12];
						printf("GENUS Kwh[%6ld]\n",templong1/10);
						sprintf(temp,"GENUS Kwh[%6ld]\n",templong1/10);
						txt->text(temp);
					}
				}
				else
				{
					templong1=0;
					printf("Error In Reading GENUS Kwh[%6ld]\n",templong1);
					sprintf(temp,"Error In Reading GENUS Kwh[%6ld]\n",templong1);
					txt->text(temp);
				}

			}

			fltk::flush();
			j++;
			fprintf(stdout,"\n j value[%d]\t count value [%d] \n",j,count1);
		}

	}
	Close();
	ProceedButton->activate();
	txt->text(" ");
	txt->text("Data Received ...\n Completed");
	fltk::flush();
}

void cb_chSelectMeter(fltk::Choice *ip, void *) 
{
	txt->text(" ");
	fltk::flush();
	if(ip->value() == 0) {
		txt->text("Invalid Selection...");
		fltk::flush();
		return;
	}
	count1 = atoi(Data[ip->value()-1][0]);
	fprintf(stdout,"---%s---%d",Data[ip->value()-1][0],count1);
	strcpy(SelectedBaudRate, Data[ip->value()-1][1]);
	strcpy(MeterMake,Data[ip->value()-1][2]);
	strcpy(MeterInode, Data[ip->value()-1][3]);

	for(int k=0;k<count1;k++)
	{
		strcpy(Command[k], Data[ip->value()-1][k+4]);
#ifdef DEBUG
		fprintf(stdout,"\n Command-buffer[%d]--->%s\n",k,Data[ip->value()-1][k+4]);
#endif
	}
	return;
}

int MainMenu() 
{
	int y = 0;
	memset(Command, 0x00, sizeof Command);
	memset(Selected, 0x00, sizeof Selected);
	memset(MeterInode, 0x00, sizeof MeterInode);
	memset(MeterMake, 0x00 ,sizeof MeterMake);
	memset(SelectedBaudRate, 0x00, sizeof SelectedBaudRate);
	if(SplitConfig() < 0) 
	{
		fltk::alert("Invalid Data Found...");
		return 0;
	}
	Main_grp = new fltk::Group(0, 0, 320, 240, "");
	Main_grp->set_vertical();
	Main_grp->begin();
	{
		ib = new fltk::InputBrowser(00, y, 320, 40, " ");
		ib->take_focus();
                ib->textfont(fltk::TIMES_BOLD);
                ib->textsize(16);
                ib->text(" ---SELECT---");
                ib->add("USB");
                ib->add("LPR");
		ib->callback((fltk::Callback*)cb_InputBrowser);
	}
	y = y + 45;
	{
		chCmd = new fltk::Choice(00, y, 320, 40, "");
		chCmd->box(fltk::FLAT_BOX);
		chCmd->textfont(fltk::TIMES_BOLD);
		chCmd->when(fltk::WHEN_CHANGED);
		chCmd->textsize(16);
		chCmd->add("---SELECT---");
		for(int i = 0; i < splitMeter; i++){
			fprintf(stdout, "Meter : %d\t Node : %s\n", i, Data[i][3]);
			chCmd->add(Data[i][3]);
		}
		chCmd->callback((fltk::Callback*)cb_chSelectMeter);
	}
	y = y + 45;
	{
		ProceedButton = new fltk::Button(00, y, 320, 40, "Proceed.");
		ProceedButton->box(fltk::FLAT_BOX);
		ProceedButton->labelfont(fltk::TIMES_BOLD);
		ProceedButton->labelsize(16);
		ProceedButton->shortcut('\r');
		ProceedButton->activate();
		ProceedButton->show();
		ProceedButton->callback((fltk::Callback*)cb_btnProceed);
	}
	y = y + 45;
	{
		txt = new fltk::TextDisplay(00, y, 320, 85, "");
		txt->box(fltk::FLAT_BOX);
		txt->color((fltk::Color)246);
		txt->textfont(fltk::TIMES_BOLD);
		txt->deactivate();
		txt->textsize(16);
		txt->text("");
	}
	
}

int main(int argc, char **argv) 
{
	w = new fltk::Window(0, 0, 320, 240, " ");
	w->box(fltk::FLAT_BOX);
	w->color((fltk::Color)246);
	w->begin();
		MainMenu();
	w->end();
	w->show(argc, argv);
	return fltk::run();			
}
