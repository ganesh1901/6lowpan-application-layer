export DISPLAY=:0.0
/home/debian/6lowpan-app/bin/6lowpan

