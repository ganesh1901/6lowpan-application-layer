#includ <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <poll.h>
#include <fcntl.h>
#include <termios.h>
#include <dirent.h>
#include <sys/types.h>
#include <time.h>

#define ConfigFile "/home/debian/changemacid.txt"

int Initialize(char *);
int SendCommand(char *, int);
int Response(char *, int, int);
int ChangeMachineID();
void Close();

static int fd = -1;

struct pollfd pollmsp;

struct speed_map {
    unsigned short speed;
    unsigned short value;
};

static const struct speed_map speeds[] = {
    {B0, 0},
    {B50, 50},
    {B75, 75},
    {B110, 110},
    {B134, 134},
    {B150, 150},
    {B200, 200},
    {B300, 300},
    {B600, 600},
    {B1200, 1200},
    {B1800, 1800},
    {B2400, 2400},
    {B4800, 4800},
    {B9600, 9600},
#ifdef    B19200
    {B19200, 19200},
#elif defined(EXTA)
    {EXTA, 19200},
#endif
#ifdef    B38400
    {B38400, 38400/256 + 0x8000U},
#elif defined(EXTB)
    {EXTB, 38400/256 + 0x8000U},
#endif
#ifdef B57600
    {B57600, 57600/256 + 0x8000U},
#endif
#ifdef B115200
    {B115200, 115200/256 + 0x8000U},
#endif
#ifdef B230400
    {B230400, 230400/256 + 0x8000U},
#endif
#ifdef B460800
    {B460800, 460800/256 + 0x8000U},
#endif
#ifdef B921600
    {B921600, 921600/256 + 0x8000U},
#endif
};

#define NUM_SPEEDS         (sizeof(speeds)/sizeof(speeds[0]))

static unsigned int tty_baud_to_value(speed_t speed) {

    int i = 0;
    do {

        if (speed == speeds[i].speed) {

            if (speeds[i].value & 0x8000U) {

                return ((unsigned long) (speeds[i].value) & 0x7fffU) * 256;
            }
            return speeds[i].value;
        }
    } while (++i < NUM_SPEEDS);

    return 0;
}

static speed_t tty_value_to_baud(unsigned int value) {

    int i = 0;
    do {

        if (value == tty_baud_to_value(speeds[i].speed)) {   //Trying to obtain the Valid BaudRate for the value passed

            return speeds[i].speed;        //returning the Valid BaudRate 
        }
    } while (++i < NUM_SPEEDS);  //checking for Baudrate

    return (speed_t) ~0;
}

static int htoi(const char c) {
        switch(c) {
                case 'a':
                case 'A': return 10;
                case 'b':
                case 'B': return 11;
                case 'c':
                case 'C': return 12;
                case 'd':
                case 'D': return 13;
                case 'e':
                case 'E': return 14;
                case 'f':
                case 'F': return 15;
                default: return (int)c - 0x30;
        }
}

static int atoh(const char *a) {
        return (16*htoi(a[0]) + htoi(a[1]));
}

static int Ascii2hex(char *Ascbuf,char *Hexbuf,int Asclen) {
        int ii,Hexcnt = 0,Ascnt = 0;
        if(Asclen % 2)                                                          //Checking the input count.
                return -1;

        for(Ascnt=0;Ascnt < Asclen;Ascnt+=2,Hexcnt++)
                Hexbuf[Hexcnt] = atoh((Ascbuf+Ascnt));                          //converting each hex byte into Ascii.

        return Hexcnt;
}

static void h2a(char* hex,char* asc,int Hlen) {
        int i;
        for(i=0;i<Hlen;i++)
        {
                switch(hex[i]){
                        case 0x0A: asc[i]='A';break;
                        case 0x0B: asc[i]='B';break;
                        case 0x0C: asc[i]='C';break;
                        case 0x0D: asc[i]='D';break;
                        case 0x0E: asc[i]='E';break;
                        case 0x0F: asc[i]='F';break;
                        default: asc[i]=hex[i]+0x30;break;
                }
        }
}

static int Hex2Ascii(char *Hexbuf, char *Ascbuf, int HexLength) {
        int i,j=0;
        char temp[HexLength*2];
        memset(Ascbuf, 0x00, HexLength*2);
        for(i=0; i<HexLength;i++,j+=2) {
                temp[j]=(char)((Hexbuf[i] >> 4) & 0x0F);                        //Getting Each byte.
                temp[j+1] =(char)(Hexbuf[i] & 0x0F);
        }
        h2a(temp,Ascbuf,j);
        return j;
}

int Initialize(char *serialPort) {
  	struct termios options;
	speed_t value;
	char BaudRate[40];
	memset(BaudRate, 0x00, sizeof BaudRate);
	FILE *fp = fopen(ConfigFile, "r");
        if(fp == NULL) 
                return -3;
	
        fgets(BaudRate, 256, fp);
        fclose(fp);
	if((fd = open (serialPort, O_RDWR | O_NOCTTY )) < 0)
		return -1;

  	else
  	{
    		tcgetattr(fd, &options);
		value = tty_value_to_baud(atoi(BaudRate));
		if (value != (speed_t)~0) {
			cfsetispeed(&options, value);
			cfsetospeed(&options, value);
		}
		else
			return -2;
    		options.c_cflag &= ~PARENB;
    		options.c_cflag &= ~CSTOPB;
    		options.c_cflag &= ~CSIZE;
    		options.c_cflag |=  CS8;
    		options.c_iflag &= ~ICRNL;
    		options.c_cflag &= ~CRTSCTS;
    		options.c_lflag &= ~(ICANON | ECHO | ECHOE| ISIG);

		options.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP
                           | INLCR | IGNCR | ICRNL | IXON);
	        options.c_oflag &= ~OPOST;
        	options.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);

    		options.c_cc[VMIN] = 1;
    		options.c_cc[VTIME] = 200;

		pollmsp.fd = fd;
                pollmsp.events = POLLIN;

    		tcsetattr(fd,TCSANOW,&options);
		tcflush(fd, TCIOFLUSH);
		return fd;
  	}
}

int Request(char *cmd, int Len) {   
#ifdef DEBUG
	int i;
	fprintf(stderr, "Port Req : ");
	for(i = 0; i < Len; i++)
		fprintf(stderr, "%02X ", (cmd[i]&0x000000FF));

	fprintf(stderr, "\n");
#endif
	if(write(fd, cmd, Len) == -1)					//pushing data over serial port.
		return 1;

	return 0;
}

int Response(char *PortRes, int Len, int TimeOut) { 
 	int noof_bytes = 0, cont = 0, Total = 0;
	char ascii[100];
	memset(ascii, 0x00, sizeof ascii);
	tcflush(fd, TCIOFLUSH);
        while(1)
        {
                if(cont == 0) { 
                        poll(&pollmsp, 1, (TimeOut*1000));
		}
                else 
                        poll(&pollmsp, 1, (TimeOut*100));
                
                if((pollmsp.revents & POLLIN) == 1) {
                        noof_bytes=read(fd, PortRes+Total, Len);
                        Total+=noof_bytes;
                        usleep(100000);cont++;
                }
                else{
                        if(cont == 0) {
#ifdef DEBUG
				fprintf(stderr, "No Data Found\n");
#endif
                                return -1;
			}
                        break;
                }
        }
        return Total;
}

void Close() {
	close(fd);
}

int SendCommand(char *Data, int Length) {
	char HexData[40];
	int HexLen = -1;
	fprintf(stdout, "LIB Command : %s\n", Data);
	fprintf(stdout,"Data-length:%d--->%d\n",strlen(Data),Length);
	memset(HexData, 0x00, sizeof HexData);
	if(strlen(Data)!= Length)
		return -1;

	HexLen = Ascii2hex(Data, HexData, Length);
	
	if(HexLen == -1)
		return -2;

	if(Request(HexData, HexLen) < 0)
		return -3;

	return 0;
}

int ChangeMachineID() {
	char Buff[40], Res[128], macBuff[40];
	int hexLen = -1, i;
	memset(Buff, 0x00, sizeof Buff);
	memset(macBuff, 0x00, sizeof macBuff);
	memset(Res, 0x00, sizeof Res);
	
	FILE *fp = fopen(ConfigFile, "r");
	if(fp == NULL) 
		return -1;
	
	fgets(Res, 40, fp);
	fgets(Buff, 40, fp); 
	fclose(fp);
	memcpy(macBuff, Buff, strlen(Buff));

#ifdef DEBUG
	fprintf(stderr, "macBuff : %s\n", macBuff);
#endif
	hexLen = Ascii2hex(&Buff[0], &macBuff[0], (strlen(Buff)-1));

#ifdef DEBUG
	fprintf(stderr, "Length : %d\n", hexLen);
	fprintf(stderr, "Mac Data : ");
	for(i = 0; i < hexLen; i++)
		fprintf(stderr, "%02X ", macBuff[i]);
 	
	fprintf(stderr, "\n");
#endif	
	if(Request(macBuff, hexLen+4) < 0)
		return -2;

	if(Response(Res, 100, 10) < 0)	
		return -3;

	if(strstr(Res, "OK") == NULL)
		return -4;
#ifdef DEBUG
	fprintf(stderr, "MAC Id Changed :: RESPONSE : %s\n", Res);
#endif
	return 0;
}


/*
int main(int argc, char *argv[]) {

	if(argc < 2) {
		fprintf(stderr,"Executable expects Serialport as command ling argument\n");
		return 1;
	}
	char buff[] = "2B05820000B2";
	char ResBuff[128];
	int RetLength = -1, i;
	memset(ResBuff, 0x00, sizeof ResBuff);
	if(Initialize(argv[1]) < 0) {
		fprintf(stderr, "Initialize Failed\n");
		return 0;
	}
	RetLength = ChangeMachineID();
	if(RetLength < 0) 
		fprintf(stderr, "Unable to change MacId RES: %d\n", RetLength);*/
	
	/*if(SendCommand(buff, 12)) {
		fprintf(stderr, "Unable to Send Request\n");
		return 1;
	}
	RetLength = Response(ResBuff, 128, 10);
	if(RetLength < 0){
		fprintf(stderr, "Unable Fetch Request\n");
		return 2;
	}
	fprintf(stderr ,"Response :");
	for(i = 0; i < RetLength; i++) 
		fprintf(stderr, " %02X", ResBuff[i]);
	fprintf(stderr ,"\n");*/
	/*Close();
}*/
